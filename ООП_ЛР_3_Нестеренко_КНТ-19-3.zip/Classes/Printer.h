#pragma once

#include "Software.h"

class Printer {
public:
    void printing(Software*);   //Вызывает метод ToPrint объекта obj
};
