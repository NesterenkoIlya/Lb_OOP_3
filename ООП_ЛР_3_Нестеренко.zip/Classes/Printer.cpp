#include "Printer.h"

void Printer::printing(Software* obj) {
    obj->ToPrint(); //Вызов метода ToPrint объекта obj
}
